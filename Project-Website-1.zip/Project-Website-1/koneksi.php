<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "web_project"; // Ganti dengan nama database Anda di phpMyAdmin

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}
?>